import { Component } from '@angular/core';
import $ from  'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  public arrVal = ['checkbox 1','checkbox 2','checkbox 3'];
  bien: string = "checkbox 1,checkbox 2,checkbox 3";
  lsTemp = [];

  lsCheckbox = [
    { name: 'checkbox 1',  checked: 'checked'  },
    { name: 'checkbox 2', checked: 'checked' },
    { name: 'checkbox 3', checked: 'checked' },
    { name: 'checkbox 4', checked: '' },
    { name: 'checkbox 5', checked: '' },
    { name: 'checkbox 6', checked: '' },
    { name: 'checkbox 7', checked: ''  },
    { name: 'checkbox 8', checked: '' },
    { name: 'checkbox 9', checked: '' },
    { name: 'checkbox 10', checked: '' },
  ];

  ngOnInit() {
  }

  resetCheckbox()
  {
    this.bien = "checkbox 1,checkbox 2,checkbox 3";
    this.arrVal = ['checkbox 1','checkbox 2','checkbox 3'];
    this.lsCheckbox  = [
      { name: 'checkbox 1',  checked: 'checked'  },
      { name: 'checkbox 2', checked: 'checked' },
      { name: 'checkbox 3', checked: 'checked' },
      { name: 'checkbox 4', checked: '' },
      { name: 'checkbox 5', checked: '' },
      { name: 'checkbox 6', checked: '' },
      { name: 'checkbox 7', checked: ''  },
      { name: 'checkbox 8', checked: '' },
      { name: 'checkbox 9', checked: '' },
      { name: 'checkbox 10', checked: '' },
    ];
    console.log(this.lsCheckbox);
  }

  processChk(event : any)
  {
    var index = this.arrVal.indexOf(event.srcElement.attributes.name.nodeValue);

    //debugger;
    if(event.srcElement.checked)
    {
      if(index == -1)
          this.arrVal.push(event.srcElement.attributes.name.nodeValue);
    }
    else
    {
      if(index != -1)
        this.arrVal.splice(index,1);
    }

    this.bien = this.arrVal.join(',');
  }
}